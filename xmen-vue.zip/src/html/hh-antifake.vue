<template>
    <div>
        <div class="main clear">
        </div>
    </div>
</template>

<script>
export default {
    name: 'Antifake',
    data() {
        return {
        }
    }
};
</script>
