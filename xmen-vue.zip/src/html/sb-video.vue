<template>
    <div class="video">
        <div class="video-detail-title">视频标题</div>
        <div class="video-detail-content">
            <video class="video-player" src=""></video>
        </div>
        <div class="video-detail-info">
            <div class="container">
                <h3 class="title">视频信息</h3>
                <div class="content">视频信息视频信息视频信息视频信息视频信息视频信息</div>
            </div>
        </div>
    </div>
</template>

<!--[if lte IE 8]>
 <script type="text/javascript" src="https://cdn.bootcss.com/html5shiv/r29/html5.min.js"></script>
<![endif]-->

<script>
import thumbnail from '@/img/main-bottom.png';
export default {
    name: 'VideoDetail',
    data() {
        return {
        }
    }
};
</script>
