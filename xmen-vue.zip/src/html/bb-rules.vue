<template>
    <div class="main clear">
        <MainRight/>
        <div class="main-left-area">
            <div class="article">
                <div class="article-section">
                    <h3 class="article-section-title">
                        <div class="article-section-name">第一章</div>总则</h3>
                    <div class="article-section-paragraph">
                        <div class="article-section-name">第一条</div>
                        <div class="article-section-content">
                            两色球由亚洲福利彩票有限公司发行，定期开奖。
                        </div>
                    </div>
                    <div class="article-section-paragraph">
                        <div class="article-section-name">第二条</div>
                        <div class="article-section-content">两色球实行自愿购买，凡购买者均被视为同意并遵守本规则。</div>
                    </div>
                    <div class="article-section-paragraph">
                        <div class="article-section-name">第三条</div>
                        <div class="article-section-content">不得向未成年人销售彩票或兑付奖金。</div>
                    </div>
                </div>
                <div class="article-section">
                    <h3 class="article-section-title">
                        <div class="article-section-name">第二章</div>投注</h3>
                    <div class="article-section-paragraph">
                        <div class="article-section-name">第一条</div>
                        <div class="article-section-content">两色球投注区分为红色球号码区和蓝色球号码区，红色球号码区由1-30共三十个号码组成，蓝色球号码区由1-14共十四个号码组成。投注时选择6个红色球号码和1个蓝色球号码组成一注进行单式投注，每注金额1000卡瑞尔（0.25美元）。</div>
                    </div>
                    <div class="article-section-paragraph">
                        <div class="article-section-name">第二条</div>
                        <div class="article-section-content">投注方式分为单式投注，复式投注和胆拖投注</div>
                    </div>
                    <div class="article-section-paragraph">
                        <div class="article-section-content">
                            <p>单式投注：</p>
                            <p> 单式投注是从红色球号码中选择6个号码，从蓝色球号码中选择1个号码，组合为一注投注号码的投注。 </p>
                            <p>复式投注有三种： </p>
                            <p> （一）红色球号码复式：从红色球号码中选择7--16个号码，从蓝色球号码中选择1个号码，组合成多注投注号码的投注。 </p>
                            <p> （二）蓝色球号码复式：从红色球号码中选择6个号码，从蓝色球号码中选择2--16个号码，组合成多注投注号码的投注。</p>
                            <p> （三）全复式：从红色球号码中选择7--16个号码，从蓝色球号码中选择2--16个号码，组合成多注投注号码的投注。</p>
                            <p>胆拖投注：</p>
                            <p> 由“胆码”加“拖码”组成。“胆码”是指每一注组合中都包含的号码，“拖码”是指所选号码中除“胆码”以外的其它号码。“胆码”加“拖码”数量之和必须多于单式投注的号码个数；“胆码”和“拖码”不能重复；“胆码”的个数要少于单式投注的个数。</p>
                        </div>
                    </div>
                    <div class="article-section-paragraph">
                        <div class="article-section-name">第三条</div>
                        <div class="article-section-content">购买者可对其选定的投注号码进行多倍投注，投注倍数范围为2-100倍。单张彩票的投注金额最高不得超过10000000卡瑞尔（2500美元）。</div>
                    </div>
                    <div class="article-section-paragraph">
                        <div class="article-section-name">第四条</div>
                        <div class="article-section-content">若因销售终端故障、通讯线路故障和投注站信用额度受限等原因造成投注不成功，应退还购买者投注金额。</div>
                    </div>
                </div>
                <div class="article-section">
                    <h3 class="article-section-title">
                        <div class="article-section-name">第三章</div>开奖</h3>
                    <div class="article-section-paragraph">
                        <div class="article-section-name">第一条</div>
                        <div class="article-section-content"> 两色球按期销售，每周二、四、日开奖，期号以开奖日界定，按日历年度编排。 </div>
                    </div>
                    <div class="article-section-paragraph">
                        <div class="article-section-name">第二条</div>
                        <div class="article-section-content">每期开奖后，亚洲福利彩票有限公司向社会公布开奖号码、当期销售总额、各奖级中奖情况及奖池资金余额等信息，并将开奖结果通知销售网点。</div>
                    </div>
                </div>
                <div class="article-section">
                    <h3 class="article-section-title">
                        <div class="article-section-name">第四章</div>中奖</h3>
                    <div class="article-section-paragraph">
                        <div class="article-section-name">第一条</div>
                        <div class="article-section-content"> “两色球”彩票以投注者所选单注投注号码与当期开出中奖号码相符的球色和个数确定中奖等级：</div>
                    </div>
                    <div class="article-section-paragraph">
                        <div class="article-section-content">
                            <p>一等奖：7个号码相符（6个红色球号码和1个蓝色球号码）（红色球号码顺序不限，下同）</p>
                            <p>二等奖：6个红色球号码相符；</p>
                            <p>三等奖：5个红色球号码和1个蓝色球号码相符；</p>
                            <p>四等奖：5个红色球号码相符 或者 4个红色球号码和1个蓝色球号码相符；</p>
                            <p>五等奖：4个红色球号码相符 或者 3个红色球号码和1个蓝色球号码相符；</p>
                            <p>六等奖：1个蓝色球号码相符（有无红色球号码相符均可）。</p>
                        </div>
                    </div>
                </div>
                <div class="article-section">
                    <h3 class="article-section-title">
                        <div class="article-section-name">第五章</div>奖级</h3>
                    <div class="article-section-paragraph">
                        <div class="article-section-name">第一条</div>
                        <div class="article-section-content"> 每期奖金由当期销售额*63%加上往期累计的奖池组成，另外的2%销售额作为调节基金累积。</div>
                    </div>
                    <div class="article-section-paragraph">
                        <div class="article-section-name">第二条</div>
                        <div class="article-section-content">“两色球”奖级设置分为高等奖和低等奖。一等奖为高等奖，二至六等奖为低等奖。高等奖采用浮动设奖，低等奖采用固定设奖。当期奖金减去当期低等奖奖金为当期高等奖奖金。</div>
                    </div>
                    <div class="article-section-paragraph">
                        <div class="article-section-content">
                            <p>单式投注设奖级如下：</p>
                            <p>一等奖：奖金总额为当期高奖级奖金的100%，单注奖金按注均分，单注最高限额封顶2000000000卡瑞尔( 500000美元)。</p>
                            <p>二等奖：单注奖金固定为40000000卡瑞尔（10000美元）。</p>
                            <p>三等奖：单注奖金固定为4000000卡瑞尔（1000美元）。</p>
                            <p>四等奖：单注奖金固定为200000卡瑞尔（50美元）。</p>
                            <p>五等奖：单注奖金固定为8000卡瑞尔（2美元）。</p>
                            <p>六等奖：单注奖金固定为2000卡瑞尔（0.5美元）。</p>
                        </div>
                    </div>
                    <div class="article-section-paragraph">
                        <div class="article-section-name">第三条</div>
                        <div class="article-section-content">高奖级中奖者按各奖级的中奖注数，平均分配该奖级奖金，并以瑞尔（美分）为单位取整计算；低奖级中奖者按各奖级的单注固定奖金获得相应奖金。</div>
                    </div>
                    <div class="article-section-paragraph">
                        <div class="article-section-name">第四条</div>
                        <div class="article-section-content">当期每注投注号码只有一次中奖机会，不能兼中兼得，特别设奖除外。</div>
                    </div>
                    <div class="article-section-paragraph">
                        <div class="article-section-name">第五条</div>
                        <div class="article-section-content">如果高等奖（一等奖）的每注奖金，低于二等奖的每注奖金40000000瑞尔（10000美元），由调节基金补足40000000瑞尔（10000美元）。 </div>
                    </div>
                    <div class="article-section-paragraph">
                        <div class="article-section-name">第六条</div>
                        <div class="article-section-content">当期奖金不足部分由调节基金补充；加上调节基金还不足时，另再加上发行费垫支。</div>
                    </div>
                </div>

                <div class="article-section">
                    <h3 class="article-section-title">
                        <div class="article-section-name">第六章</div>兑奖</h3>
                    <div class="article-section-paragraph">
                        <div class="article-section-name">第一条</div>
                        <div class="article-section-content">“两色球”彩票兑奖当期有效。每期开奖次日起，兑奖期限为60天，逾期未兑奖者视为弃奖，弃奖奖金进入调节基金。</div>
                    </div>
                    <div class="article-section-paragraph">
                        <div class="article-section-name">第二条</div>
                        <div class="article-section-content">中奖者必须向亚洲福利彩票有限公司提交完整的兑奖彩票，因玷污、损坏等原因造成不能正确识别号码的，不能兑奖。</div>
                    </div>
                    <div class="article-section-paragraph">
                        <div class="article-section-name">第三条</div>
                        <div class="article-section-content">亚洲福利彩票有限公司可以查验中奖者的中奖彩票及有效身份证件，中奖者兑奖时必须配合。</div>
                    </div>
                </div>
                <div class="article-section">
                    <h3 class="article-section-title">
                        <div class="article-section-name">第七章</div>附则</h3>
                    <div class="article-section-paragraph">
                        <div class="article-section-name">第一条</div>
                        <div class="article-section-content">本规则自批准之日起执行</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import MainRight from './MainRight.vue';
export default {
    name: 'Rules',
    data() {
        return {}
    },
    components: {
        MainRight
    }
};
</script>
